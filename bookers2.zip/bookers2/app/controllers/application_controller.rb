class ApplicationController < ActionController::Base
  # top, about の2つのアクションのみ、ログイン無しでもアクセス可能にする
  before_action :authenticate_user!, except: [:top, :about]
  
  before_action :configure_permitted_parameters, if: :devise_controller?
  
  # 新規ユーザー登録やログインをした直後に UsersControllerのshowアクションが実行される
  def after_sign_in_path_for(resource)
    user_path(current_user) 
  end
  
  protected
  # sign upの際にemailのデータ操作が許可される
  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:email, :name])
  end
end
