# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '514b0dd00dc3879aede4b44ffa13ab27bc8ac88414cefb169b5c8e7f1c58aba72b9bbb5690eee2f9c4d1fea0fba0c61b0449feb625e3a269399427d44f1e9ecd'